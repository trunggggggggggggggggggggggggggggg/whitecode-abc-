import sys

def decode_message(input_file):
    with open(input_file, 'r') as f:
        lines = f.readlines()
    
    binary = ''
    for line in lines:
        spaces = len(line.rstrip('\n')) - len(line.rstrip(' \n'))
        if spaces == 1:
            binary += '0'  # 1 space for bit 0
        elif spaces == 2:
            binary += '1'  # 2 spaces for bit 1
    
    message = ''
    for i in range(0, len(binary), 8):
        byte = binary[i:i+8]
        if len(byte) == 8:
            message += chr(int(byte, 2))
    return message

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 decode.py input_file")
        sys.exit(1)
    result = decode_message(sys.argv[1])
    print(result)  # In ra màn hình
    with open('decode.txt', 'w') as f:
        f.write(result)  # Lưu vào file decode.txt
