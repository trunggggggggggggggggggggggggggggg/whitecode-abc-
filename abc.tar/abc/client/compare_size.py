import sys
import os

def compare_sizes(input_file, output_file):
    input_size = os.path.getsize(input_file)
    output_size = os.path.getsize(output_file)
    difference = abs(input_size - output_size)
    result = (f"Size of {input_file}: {input_size} bytes\n"
              f"Size of {output_file}: {output_size} bytes\n"
              f"Difference: {difference} bytes")
    print(result)  # In ra màn hình
    with open('size_comparison.txt', 'w') as f:
        f.write(result)  # Lưu vào file size_comparison.txt

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 compare_size.py input_file output_file")
        sys.exit(1)
    compare_sizes(sys.argv[1], sys.argv[2])
