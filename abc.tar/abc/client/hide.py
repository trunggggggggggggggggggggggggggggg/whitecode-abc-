import sys

def hide_message(input_file, output_file, message):
    binary = ''.join(format(ord(c), '08b') for c in message)
    with open(input_file, 'r') as f:
        lines = f.readlines()
    
    if len(binary) > len(lines):
        print("Error: Message too long for the number of lines.")
        return
    
    with open(output_file, 'w') as f:
        for i, line in enumerate(lines):
            line = line.rstrip('\n')
            if i < len(binary):
                if binary[i] == '0':
                    line += ' '  # 1 space for bit 0
                elif binary[i] == '1':
                    line += '  '  # 2 spaces for bit 1
            f.write(line + '\n')

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python3 hide.py input_file output_file message")
        sys.exit(1)
    hide_message(sys.argv[1], sys.argv[2], sys.argv[3])
